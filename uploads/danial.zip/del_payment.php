<?php

	$conn=mysqli_connect("localhost","root","","mmu")or die("Can't Connect...");
	$id=$_GET['sid'];
	$query="DELETE FROM payment WHERE payment_id =$id";

	mysqli_query($conn,$query);

	if(mysqli_query($conn,$query))
	{
				echo ("<script LANGUAGE='JavaScript'>
				window.alert('Succesfully Deleted!');
				window.location.href='http://localhost/MMU-store/user-admin/payment_admin.php';
				</script>");
	}
	else
	{
				echo"<script>alert('Payment Failed to Update!')</script>";
	}



?>

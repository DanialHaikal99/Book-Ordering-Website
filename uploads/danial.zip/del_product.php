

<?php

			$conn=mysqli_connect("localhost","root","","mmu")or die("Can't Connect...");

			$id=$_GET['sid'];
			$query = "DELETE FROM product WHERE product_id=$id";
			mysqli_query($conn, $query);

			if(mysqli_query($conn,$query))
			{
						echo ("<script LANGUAGE='JavaScript'>
						window.alert('Succesfully Deleted!');
						window.location.href='http://localhost/MMU-store/user-admin/view_admin.php';
						</script>");
			}
			else
			{
						echo"<script>alert('Product Information Failed to Delete!')</script>";
			}

			#header("Location: view_admin.php");
?>

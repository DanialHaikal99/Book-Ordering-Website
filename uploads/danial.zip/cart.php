<?php

      session_start();

      $connect = mysqli_connect("localhost", "root", "", "mmu");

      $id = session_id();
      $username = $_SESSION['username'];

      $query = "SELECT * FROM user WHERE student_username = '$username'";
      $result = mysqli_query($connect, $query);
      $row = mysqli_fetch_assoc($result);
      echo $username;

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="author" content="harrnish - ig@harrnish">
      <link rel="icon" href="yourIconUrl" type="image/gif" sizes="16x16">
      <title>Cart</title>

      <!-- external stylesheet -->
      <link rel="stylesheet" href="stylecart.css">

      <!-- bootstrapcdn -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- icon pack -->
      <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

      <!-- google font -->
      <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">

      <!-- jquery cdn -->
      <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

      <!-- tweenmax (greensock) cdn -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.2/TweenMax.min.js"></script>

      <!-- for on scroll animations -->
      <link rel="stylesheet" href="animate.css">
      <script src="wow.min.js"></script>
</head>
</head>
<body>
      <div class="product-container">

            <!-- NAVIGATION STARTS -->

            <div class="nav">
                  <div class="menu-open">
                        <ion-icon name="menu"></ion-icon>
                  </div>
                  <div class="brand">
                        <span><a href="index.html">wordoutlet</a></span>
                  </div>
                  <div class="cart">
                        <ion-icon name="cart"></ion-icon>
                  </div>
                  <div class="menu">
                        <div class="menu-close">
                              <ion-icon name="close"></ion-icon>
                        </div>
                        <ul>
                              <li><a href="index.html">Home</a></li>
                              <li><a href="shop.html">collection</a></li>
                              <li><a href="product.html">Product</a></li>
                              <li><a href="about.html">Our story</a></li>
                              <li><a href="contact.html">Contact</a></li>
							  <li><a href="feedback.html">Feedback</a></li>
                        </ul>
                        <div class="media-menu">
                              <ul>
                                    <li><ion-icon name="logo-facebook"></ion-icon></li>
                                    <li><ion-icon name="logo-instagram"></ion-icon></li>
                                    <li><ion-icon name="logo-twitter"></ion-icon></li>
                                    <li><ion-icon name="logo-pinterest"></ion-icon></li>
                              </ul>
                        </div>
                  </div>
            </div>


            <!-- NAVIGATION ENDS -->

            <!-- CART STARTS HERE -->

			<div class="about-hero">
                  <div class="container-fluid hero wow fadeInUp">
                        <h1 id="hero-title">CART</h1>
                  </div>

                  <div class="container content">

                  <!--Header for Add to Cart-->
						      <h3 style="font-family:Larsseit;" class="wow fadeInUp" data-wow-delay="0.5s">Item Added To Cart</h3><hr/>

                  <!--Add to Cart form-->
                  <form>
						<section class="container content-section">
								<div class="cart-row">
									<span class="cart-item cart-header cart-column">ITEM</span>
									<span class="cart-price cart-header cart-column">PRICE</span>
									<span class="cart-quantity cart-header cart-column">QUANTITY</span>
								</div>

						<div class="cart-item">

    							<div class="cart-row">

                        <?php

                              $query = "SELECT * FROM cart ORDER BY id";
                              $result = mysqli_query($connect, $query);

                              while($row = mysqli_fetch_assoc($res))
                        ?>

        								<div class="cart-item cart-column">
                              <label><img src="data:image;base64,<?php echo $row['product_image'];?>" style="width:50%;"/></Label>
            									<span class="cart-item-title"><?php echo $row['product_name']; ?></span>
        								</div>

        								<span class="cart-price cart-column">RM <?php echo $row['product_price']; ?></span>

        								<div class="cart-quantity cart-column">
            									<input class="cart-quantity-input" type="number" value="1">

                              <a href="del_product.php?sid='.$row['product_id'].' "class="btn btn-danger height-auto btn-sm">X</a>
            									<!--<button class="btn-danger" type="button">REMOVE</button>-->
        								</div>
                  </div>

						</div>

						<div class="cart-total">
								<strong class="cart-total-title">Total</strong>
								<span class="cart-total-price">RM10.00</span>
						</div>
						<button class="btn-purchase wow fadeInUp" data-wow-delay="0.6s" type="submit">Proceed To Payment</button>
						</section>

                        </form>

                  </div>
            </div>

            <!-- CART ENDS HERE -->


            <div class="whitespaces"></div>

            <!-- FOOTER STARTS -->

            <div class="container-fluid footer">
                  <div class="section container">
                        <footer>
                              <div class="row">
                                    <div class="col-lg-3 block">
                                          <p>Wordoutlet, 3581 Lunneta Street,
                                          <br>
                                          Siesta Key, Florida. 20002,
                                          <br>
                                          USA</p>
                                    </div>
                                    <div class="col-lg-3 block">
                                          <p>FAQs
                                          <br>
                                          Return Policy
                                          <br>
                                          Shipping</p>
                                    </div>
                                    <div class="col-lg-3 block">
                                          <p>Careers
                                          <br>
                                          Community
                                          <br>
                                          Wholesale</p>
                                    </div>
                                    <div class="col-lg-3 block">
                                          <div class="media">
                                                <ul>
                                                      <li><ion-icon name="logo-facebook"></ion-icon></li>
                                                      <li><ion-icon name="logo-instagram"></ion-icon></li>
                                                      <li><ion-icon name="logo-twitter"></ion-icon></li>
                                                      <li><ion-icon name="logo-pinterest"></ion-icon></li>
                                                </ul>
                                          </div>
                                    </div>
                              </div>
                        </footer>
                  </div>
            </div>

            <!-- FOOTER ENDS -->
      </div>

      <script type="text/javascript">

      //Scroll reveal animations

      new WOW().init();

      //Scroll activated background change
      $(function() {
            $(document).scroll(function() {
                  var $nav = $(".nav");
                  $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
            });
      });

      //Toggle MENU

      var t1 = new TimelineMax({paused: true});
      t1.to(".menu", 0.5, {
            left: "0%",
            ease: Power2.easeInOut
      });

      t1.reverse();
      $(document).on("click", ".menu-open", function() {
            t1.reversed(!t1.reversed());
      });
      $(document).on("click", ".menu-close", function() {
            t1.reversed(!t1.reversed());
      });

      </script>
</body>
</html>

 <?php
	session_start();

	$connect = mysqli_connect('localhost', 'root', '', 'mmu');

	$q="select * from student";
	$res=mysqli_query($connect,$q) or die("Can't Execute Query...");

?>
<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="author" content="harrnish - ig@harrnish">
      <link rel="icon" href="yourIconUrl" type="image/gif" sizes="16x16">
      <title>Student List</title>

	  <!---Extra--->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
		<!----Extra end--->

      <!-- external stylesheet -->
      <link rel="stylesheet" href="style.css">

      <!-- bootstrapcdn -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- icon pack -->
      <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

      <!-- google font -->
      <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">

      <!-- jquery cdn -->
      <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

      <!-- tweenmax (greensock) cdn -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.2/TweenMax.min.js"></script>

      <!-- for on scroll animations -->
      <link rel="stylesheet" href="animate.css">
      <script src="wow.min.js"></script>
</head>
<body>
      <div class="shop-container">

            <!-- NAVIGATION STARTS -->

            <div class="nav">
                  <div class="menu-open">
                        <ion-icon name="menu"></ion-icon>
                  </div>
                  <div class="brand">
                        <a href="index_Admin.php"><img src="images/logo.png" alt=""></img></a>
                  </div>
				  <div class="cart">
                        <?php echo $_SESSION['username'];?>
                  </div>
                  <div class="menu">
                        <div class="menu-close">
                              <ion-icon name="close"></ion-icon>
                        </div>
                        <ul>
                              <li><a href="index_admin.php">Home</a></li>
                              <li><a href="view_admin.php">Product</a></li>
							  <li><a href="payment_admin.php">Payment</a></li>
                              <li><a href="feedback_admin.php">Feedback</a></li>
							  <li><a href="studentlist_admin.php">Student List</a></li>
							  <li><a href="logout.php">Logout</a></li>
                        </ul>
                        <div class="media-menu">
                              <ul>
                                    <li><ion-icon name="logo-facebook"></ion-icon></li>
                                    <li><ion-icon name="logo-instagram"></ion-icon></li>
                                    <li><ion-icon name="logo-twitter"></ion-icon></li>
                                    <li><ion-icon name="logo-pinterest"></ion-icon></li>
                              </ul>
                        </div>
                  </div>
            </div>

            <!-- NAVIGATION ENDS -->

            <div class="whitespaces"></div>

            <!-- COLLECTION STARTS -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title" style="text-align:center;">STUDENT LIST</h1><br>
			<div class="entry" align="center">

					<table border='1' WIDTH="90%">
						<tr>
<td style="color:darkgreen; text-align:center;"" WIDTH="50px"><b><u>NO</u></b></td>
<td style="color:darkgreen; text-align:center;"" WIDTH="150px"><b><u>STUDENT ID</u></b></td>
<TD style="color:darkgreen; text-align:center;"" WIDTH="150px"><b><u>STUDENT NAME</u></b></TD>
<TD style="color:darkgreen; text-align:center;"" WIDTH="150px"><b><u>EMAIL</u></b></TD>
<TD style="color:darkgreen; text-align:center;"" WIDTH="150px"><b><u>ADDRESS</u></b></TD>
<TD style="color:darkgreen; text-align:center;"" WIDTH="150px"><b><u>PHONE</u></b></TD>
<TD style="color:darkgreen; text-align:center;"" WIDTH="70px"><b><u>DELETE</u></b></TD>

						</tr>
						<?php
							$count=1;
							while($row=mysqli_fetch_assoc($res))
							{
							echo '<tr>
										<td style="text-align:center;">'.$count.'
										<td>'.$row['student_id'].'
										<td>'.$row['student_username'].'
										<td>'.$row['student_email'].'
										<td>'.$row['student_address'].'
										<td>'.$row['student_phone'].'
										<td style="text-align:center;"><a href="del_student.php?sid='.$row['student_id'].'">Delete</a>
									</tr>';
									$count++;
							}
						?>

					</TABLE>

			</div>

		</div>

	</div>
	<!-- end content -->
	  <!-- COLLECTION END -->
      <script type="text/javascript">

      //Scroll reveal animations

      new WOW().init();

      //Scroll activated background change
      $(function() {
            $(document).scroll(function() {
                  var $nav = $(".nav");
                  $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
            });
      });

      //Toggle MENU

      var t1 = new TimelineMax({paused: true});
      t1.to(".menu", 0.5, {
            left: "0%",
            ease: Power2.easeInOut
      });

      t1.reverse();
      $(document).on("click", ".menu-open", function() {
            t1.reversed(!t1.reversed());
      });
      $(document).on("click", ".menu-close", function() {
            t1.reversed(!t1.reversed());
      });


      </script>

</body>
</html>

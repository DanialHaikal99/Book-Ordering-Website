<?php

	session_start();
	include("connect.php");
	echo $_SESSION['username'];

	$id=$_GET['sid'];
	echo	$id;
	$query="SELECT * from product WHERE product_id = $id";
	$res=mysqli_query($conn, $query) or die("Can't Execute Query...");
	$row = mysqli_fetch_assoc($res);
	mysqli_free_result($res);




?>
<!DOCTYPE html>
<html>
<head><title>Edit Product</title>
  <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="author" content="harrnish - ig@harrnish">
      <link rel="icon" href="yourIconUrl" type="image/gif" sizes="16x16">
      <title>Edit Product - wordoutlet</title>

	  <!---Extra--->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
		<!----Extra end--->

      <!-- external stylesheet -->
      <link rel="stylesheet" href="style.css">

      <!-- bootstrapcdn -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- icon pack -->
      <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

      <!-- google font -->
      <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">

      <!-- jquery cdn -->
      <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

      <!-- tweenmax (greensock) cdn -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.2/TweenMax.min.js"></script>

      <!-- for on scroll animations -->
      <link rel="stylesheet" href="animate.css">
      <script src="wow.min.js"></script>


<style>
h1{
	text-align:center;
	font-family: arial;
	font-weight:bold;
}
form{
	background-color: white;
	margin:5% 30%;
	border-radius:10px;
	border:2px solid grey;
	padding:10px 20px;
}
a:hover{
	color:red;
	cursor:pointer;
}
</style>
</head>
<body>
<h1>Edit product</h1>
	<form method="post" enctype="multipart/form-data">
	<label>Product Name:</label><input type="text" name="name" value="<?php echo $row['product_name'];?>"><br><br>
	<label>Product Price:</label><input type="text" name="price" value="<?php echo $row['product_price'];?>" size="10"><br><br>
	<label>Product Description:</label><input type="text" name="des" value="<?php echo $row['product_description'];?>" size="10"><br><br>
	<label><img src="data:image;base64,<?php echo$row['product_image'];?>" style="width:50%;"/></Label>
	<label>Image:</label><input type="file" name="image" /><br><br>

		 <a href="view_admin.php">Cancel</a>
		 <input name="pls" type="submit" value="Submit">
	</form>
	<?php
	if(isset($_POST["pls"]))
	{
				$name=$_POST["name"];
				$price=$_POST["price"];
				$des=$_POST["des"];
				$image = addslashes($_FILES['image']['tmp_name']);
				$image = file_get_contents($image);
				$image = base64_encode($image);
				echo $name.$price.$image;

				$q="UPDATE product SET product_name='$name', product_price=$price , product_description='$des', product_image= '$image' where product_id=$id";
				mysqli_query($conn,$q);

				if(mysqli_query($conn,$q))
				{
							echo ("<script LANGUAGE='JavaScript'>
							window.alert('Succesfully Updated!');
							window.location.href='http://localhost/MMU-store/user-admin/view_admin.php';
							</script>");
				}
				else
				{
							echo"<script>alert('Product Information Failed to Update!')</script>";
				}

	}
	 ?>

</body>
</html>

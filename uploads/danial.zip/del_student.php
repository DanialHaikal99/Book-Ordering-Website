<?php


    $conn=mysqli_connect("localhost","root","","mmu")or die("Can't Connect...");
    $id=$_GET['sid'];
    $query="DELETE FROM student WHERE student_id =$id";

    mysqli_query($conn,$query);

    if(mysqli_query($conn,$query))
    {
          echo ("<script LANGUAGE='JavaScript'>
          window.alert('Succesfully Deleted!');
          window.location.href='http://localhost/MMU-store/user-admin/studentlist_admin.php';
          </script>");
    }
    else
    {
          echo ("<script LANGUAGE='JavaScript'>
          window.alert('SStudent List Failed to Delete!');
          window.location.href='http://localhost/MMU-store/user-admin/studentlist_admin.php';
          </script>");

    }




?>

<?php

	$conn=mysqli_connect("localhost","root","","mmu")or die("Can't Connect...");
	$id=$_GET['sid'];
	$query="DELETE FROM feedback WHERE feedback_id =$id";

	mysqli_query($conn,$query);

	if(mysqli_query($conn,$query))
	{
				echo ("<script LANGUAGE='JavaScript'>
				window.alert('Feedback Succesfully Deleted!');
				window.location.href='http://localhost/MMU-store/user-admin/feedback_admin.php';
				</script>");
	}
	else
	{
				echo"<script>alert('Feedback Failed to Delete!')</script>";
	}


?>
